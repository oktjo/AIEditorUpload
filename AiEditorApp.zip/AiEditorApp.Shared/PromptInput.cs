namespace AiEditorApp.Shared
{
    public class PromptInput
    {
        public string Prompt { get; set; }
    }
}